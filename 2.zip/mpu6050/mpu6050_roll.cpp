/*
调整时间步长dt和卡尔曼滤波器的其他参数。
根据测试调整这两个参数。
Editor Geo
version 1.0
There are some claim function is wrong
version 1.1
fix it
*/
#include <iostream>
#include <pigpio.h>
#include <cmath>
#include <unistd.h>
#include "KalmanFilter.h"

#define MPU6050_ADDR 0x68
#define PWR_MGMT_1 0x6B
#define ACCEL_XOUT_H 0x3B
#define GYRO_XOUT_H 0x43
#define CONFIG 0x1A
#define GYRO_CONFIG 0x1B
#define ACCEL_CONFIG 0x1C

KalmanFilter kalmanX, kalmanY;

void mpu6050_reset(int pi, int handle) {
    i2cWriteByteData(pi, handle, PWR_MGMT_1, 0x80);
    sleep(1);
}

void mpu6050_init(int pi, int handle) {
    mpu6050_reset(pi, handle);
    i2cWriteByteData(pi, handle, PWR_MGMT_1, 0x00);
    i2cWriteByteData(pi, handle, CONFIG, 0x01);
    i2cWriteByteData(pi, handle, GYRO_CONFIG, 0x00);
    i2cWriteByteData(pi, handle, ACCEL_CONFIG, 0x00);
}

void read_mpu6050_data(int pi, int handle, double &roll, double &pitch, double &yaw, double accel[3]) {
    char buffer[14];
    i2cReadI2CBlockData(pi, handle, ACCEL_XOUT_H, buffer, 14);

    int16_t ax = (buffer[0] << 8) | buffer[1];
    int16_t ay = (buffer[2] << 8) | buffer[3];
    int16_t az = (buffer[4] << 8) | buffer[5];

    pitch = kalmanX.updateEstimate(atan2(ax, sqrt(ay * ay + az * az)) * 180 / M_PI);
    roll = kalmanY.updateEstimate(atan2(ay, sqrt(ax * ax + az * az)) * 180 / M_PI);
    yaw = atan2(sqrt(ax * ax + ay * ay), az) * 180 / M_PI;

    accel[0] = ax / 16384.0 * 9.80665;
    accel[1] = ay / 16384.0 * 9.80665;
    accel[2] = az / 16384.0 * 9.80665;
}

int main() {
    if (gpioInitialise() < 0) {
        std::cerr << "Failed to initialize GPIO" << std::endl;
        return 1;
    }

    int handle = i2cOpen(1, MPU6050_ADDR, 0);
    if (handle < 0) {
        std::cerr << "Failed to open I2C handle" << std::endl;
        gpioTerminate();
        return 1;
    }

    mpu6050_init(1, handle);

    double roll, pitch, yaw;
    double accel[3];

    while (true) {
        read_mpu6050_data(1, handle, roll, pitch, yaw, accel);
        std::cout << "Roll: " << roll << ", Pitch: " << pitch << ", Yaw: " << yaw << std::endl;
        std::cout << "Acceleration - X: " << accel[0] << ", Y: " << accel[1] << ", Z: " << accel[2] << std::endl;
        sleep(1);
    }

    i2cClose(handle);
    gpioTerminate();
    return 0;
}
